<?php $v->layout('template'); ?>

<section class="page-section" id="login-container">

    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Cadastrar</h2>
            <h3 class="section-subheading text-dark">Seja bem vindo(a) a nossa barbearia</h3>
        </div>

        <form class="form" id="form" action="<?= url("cadastrar"); ?>" method="post">

            <div class="col-md-12">
                <div class="form-group">
                    <label for="nome">Nome:</label><br>
                    <input type="nome" id="nome" name="nome">
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="telefone">Numero de Telefone:</label><br>
                        <input type="telefone" id="telefone" name="telefone">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="email">Email:</label><br>
                                <input type="email" id="email" name="email">

                            </div>
                            <div class="form-group">
                                <label for="senha">Senha:</label><br>
                                <input type="password" id="senha" name="senha">
                            </div>

                            <div class="form-group">
                                <label for="genero">Genero:</label><br>
                                <select name="genero" style="width: 235px;">
                                    <option value="MAS">Masculino</option>
                                    <option value="FEM">Feminino</option>
                                    <option value="OUT">Outro</option>
                                </select>
                            </div>

                            <!-- retorno da aplicação aqui! -->
                            <div class="form-group">
                                <div class="form_callback"></div>
                            </div>
                            <!-- ./retorno da aplicação aqui! -->

                            <div class="form-group">
                                <?= methodForm("criar"); ?>
                                <input type="submit" value="Cadastrar">
                            </div>
                        </div>

        </form>
    </div>

</section>