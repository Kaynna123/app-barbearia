<?php

namespace Source\App;

use Source\App\Controller;
use Source\Models\Servicos;
use Source\Models\Notificacao;
use Source\Models\Agendamento;

/**
 * Web Controller
 * @package Source\Web
 */
class Auth extends Controller
{

    protected $module = 1; //dashboard

    public function __construct($router)
    {
        parent::__construct($router);
        // if (empty($_SESSION["user_id"]) || !$this->logged_user() || $this->logged_user()->clie_id != 0) {
        //     unset($_SESSION["user_id"]);
        //     flash("danger", "Acesso negado. Por favor logue-se.");
        //     $this->router->redirect("auth.login");
        // }
    }
    
    public function login(array $data): void
    {

       
        $pageName = "LOGIN";
        echo $this->view->render("login/login", [
            "title" => $pageName,
            "menuActive" => 'login'
        ]);
        return;
    }

}
