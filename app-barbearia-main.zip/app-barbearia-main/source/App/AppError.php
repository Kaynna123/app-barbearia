<?php

namespace Source\App;

use Source\App\Controller;

/**
 * APP Error
 * @package Source\Web
 */
class AppError extends Controller
{

    public function __construct($router)
    {
        parent::__construct($router);
    }

    /**
     * NAV ERROR     
     * @param array $data
     * @return void
     */
    public function error(array $data): void
    {
        $pageName = "Erro";
        echo $this->view->render("error", [
            "title" => $pageName . " {$data['errcode']} ",
            "pageName" =>  $pageName . " {$data['errcode']}",
            "error" => $data['errcode'],
        ]);
        return;
    }

    public function acessonegado(array $data): void
    {
        $pageName = "403 Acesso Negado";
        echo $this->view->render("error", [
            "title" => $pageName,
            "pageName" =>  $pageName,
            "error" => '403',
        ]);
        return;
    }
}
