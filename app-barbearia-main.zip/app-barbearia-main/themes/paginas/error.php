<?php $v->layout('template');
?>

<div class="container text-center">

    <img class="mt-100" src="<?= theme("img/erro_404.png"); ?>" height="500px" alt="404 erro" />

</div>