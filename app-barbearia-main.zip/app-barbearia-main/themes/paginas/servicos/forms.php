<?php $v->layout('template'); ?>
<section class="page-section bg-dark" id="services">
    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Serviços</h2>
            <h3 class="section-subheading text-White">Faça agora seu agendamento !!! </h3>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme('img/corte.jpg'); ?>" alt="..." />
                    <h4>Corte</h4>
                    <p class="text-white">R$ 29,99</p>
                    <a class="btn btn-primary btn-sm text-uppercase mx-2" href="#services">Agendar</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme('img/pigmentacao.jpg') ?>" alt="..." />
                    <h4>Pigmentação</h4>
                    <p class="text-white">R$ 29,99</p>
                    <a class="btn btn-primary btn-sm text-uppercase mx-2" href="#services">Agendar</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme("img/tintura.avif")?>" alt="..." />
                    <h4>Pintura</h4>
                    <p class="text-white">R$ 29,99</p>
                    <a class="btn btn-primary btn-sm text-uppercase mx-2" href="#services">Agendar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <p class="large text-dark"></p>
            </div>
        </div>
    </div>
</section>
