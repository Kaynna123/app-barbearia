<?php $v->layout('template'); ?>

<div class="container-fluid" id="h2-home">
    <div class="row text-center">
        <h2>Bem-vindo à Pole Dourado</h2>
    </div>

    <div class="row">

        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
            <div class="sidebar-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <i class="fas fa-index"></i>
                        <p class="text-white">MENU:</p>
                        <div class="mt-4" id="buttons-home">
                            <a href="<?= url("admin/servico"); ?>" class="btn btn-primary btn-lg">
                                <i class="fas fa-cut"></i> Serviços
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="mt-4" id="buttons-home">
                            <a href=" <?= url("admin/funcionario"); ?>" class="btn btn-primary btn-lg">
                                <i class="fas fa-users"></i> Funcionários
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="mt-4" id="buttons-home">
                            <a href=" <?= url("admin/financas"); ?>" class="btn btn-primary btn-lg">
                                <i class="fas fa-dollar-sign"></i> Finanças
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="mt-4" id="buttons-home">
                            <a href=" <?= url("admin/agendamentos"); ?>" class="btn btn-primary btn-lg">
                                <i class="far fa-calendar-alt"></i> Agendamentos
                            </a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="mt-4" id="buttons-home">
                            <a href=" <?= url("admin/usuarios"); ?>" class="btn btn-primary btn-lg">
                                <i class="fas fa-users-cog"></i> Usuários
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>

        <main id="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">

        </main>
    </div>
</div>
</div>