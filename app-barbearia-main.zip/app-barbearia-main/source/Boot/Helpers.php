<?php

/**
 * ###############
 * ###   URL   ###
 * ###############
 */

/**
 * @param string|null $uri
 * @return string
 */
function url(string $uri = null): string
{
    if ($uri) {
        return ROOT . "/{$uri}";
    }

    return ROOT;
}

/**
 * @return string
 */
function url_back(): string
{
    return ($_SERVER['HTTP_REFERER'] ?? url());
}


/**
 * @param string|null $path
 * @return string
 */
function theme(string $path = null): string
{
    if (strpos($_SERVER['HTTP_HOST'], "localhost")) {
        if ($path) {
            return CONF_URL_TEST . "/themes/" . CONF_THEME_STYLE . "/" . ($path[0] == "/" ? mb_substr($path, 1) : $path);
        }

        return CONF_URL_TEST . "/themes/" . CONF_THEME_STYLE;
    }

    if ($path) {
        return CONF_URL_BASE . "/themes/" . CONF_THEME_STYLE . "/" . ($path[0] == "/" ? mb_substr($path, 1) : $path);
    }

    return CONF_URL_BASE . "/themes/" . CONF_THEME_STYLE;
}


/**
 * @param string $url
 */
function redirect(string $url): void
{
    header("HTTP/1.1 302 Redirect");
    if (filter_var($url, FILTER_VALIDATE_URL)) {
        header("Location: {$url}");
        exit;
    }

    if (filter_input(INPUT_GET, "route", FILTER_DEFAULT) != $url) {
        $location = url($url);
        header("Location: {$location}");
        exit;
    }
}


/**
 * ################
 * ###   DATE   ###
 * ################
 */

/**
 * @param string $date
 * @param string $format
 * @return string
 */
function date_fmt(string $date = "now", string $format = "d/m/Y H:i:s"): string
{
    return (new DateTime($date))->format($format);
}

/**
 * @param string $date
 * @return string
 */
function date_fmt_br(string $date = "now"): string
{
    return (new DateTime($date))->format(CONF_DATE_BR);
}

/**
 * @param string $date
 * @return string
 */
function date_fmt_app(string $date = "now"): string
{
    return (new DateTime($date))->format(CONF_DATE_APP);
}

/**
 * ####################
 * ###   PASSWORD   ###
 * ####################
 */

/**
 * @param string $password
 * @return string
 */
function passwd(string $password): string
{
    return password_hash($password, CONF_PASSWD_ALGO, CONF_PASSWD_OPTION);
}

/**
 * @param string $password
 * @param string $hash
 * @return bool
 */
function passwd_verify(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}

/**
 * @param string $hash
 * @return bool
 */
function passwd_rehash(string $hash): bool
{
    return password_needs_rehash($hash, CONF_PASSWD_ALGO, CONF_PASSWD_OPTION);
}



/**
 * ################
 * ### MENSSAGE ###
 * ################
 */

/**
 * FLASH
 *
 * @param string $type
 * @param string $message
 * @return string|null
 */
function flash(string $type = null, string $message = null): ?string
{

    if ($type && $message) {

        $_SESSION["flash"] = [
            "type" => $type,
            "message" => $message
        ];

        return null;
    }

    if (!empty($_SESSION["flash"]) && $flash = $_SESSION["flash"]) {
        unset($_SESSION["flash"]);
        return "<div class=\"alert alert-{$flash["type"]}\">{$flash["message"]}</div>";
    }

    return null;
}

function image(String $image = null)
{
    if ($image) {
        if (file_exists($image)) {
            return url($image);
        }
    }

    return theme('img/no-photo-available.png');
}


/**
 * methodForm
 * @param [type] $value
 * @return void
 */
function methodForm($value, $name = "metodo")
{
    return '<input type="hidden" name="' . $name . '" value="' . $value . '">';
}

function methodFormId($id)
{
    return '<input type="hidden" name="id" value="' . $id . '">';
}


function moedaBR($value)
{
    // $formatter = new NumberFormatter('pt_BR',  NumberFormatter::CURRENCY);
    // $return = $formatter->formatCurrency($value, 'BRL');
    // return $return;
    $return =  'R$ ' . number_format($value, 2, ',', '.');
    return $return;
}


function mensagem(string $type = null, string $message = null): ?string
{
    return "<div class=\"alert alert-{$type}\">{$message}</div>";
}

function textoReduzido(string $texto, int $maxLengh = 100)
{
    return mb_strimwidth(strip_tags($texto), 0, $maxLengh, "...");
}

function saudacao()
{
    $hora_do_dia = date("H");

    if (($hora_do_dia >= 6) && ($hora_do_dia <= 12)) return "Bom Dia!";
    if (($hora_do_dia > 12) && ($hora_do_dia <= 18)) return "Boa Tarde!";
    if (($hora_do_dia > 18) && ($hora_do_dia <= 24)) return "Boa Noite!";
    if (($hora_do_dia > 24) && ($hora_do_dia < 6)) return "Bom Dia!";
}
