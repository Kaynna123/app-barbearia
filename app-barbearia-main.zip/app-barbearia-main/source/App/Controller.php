<?php

namespace Source\App;

use CoffeeCode\Router\Router;
use League\Plates\Engine;
use Source\Models\User;
use Source\Support\Message;

/**
 * Class Controller
 * @package Source\Controller
 */
abstract class Controller
{

    /** @var Engine */
    protected $view;

    /** @var Router */
    protected $router;

    /** @var Message */
    protected $message;

    /** @var User */
    protected $user;


    /**
     * Controller constructor
     * @param $router
     */
    public function __construct($router)
    {
        $this->router = $router;
        $this->view   = Engine::create(__DIR__ . "/../../themes/" . CONF_VIEW_THEME . "", "php");
        $this->view->addData([
            "router" => $this->router
        ]);
        $this->message = new Message();
    }

    public function logged_user()
    {
        if (!empty($_SESSION["user_id"])) {
            return $this->user = (new User())->findById($_SESSION["user_id"]);
        }
    }

    /**
     * @param string $param [message,redirect]
     * @param array $values [callback, type, message]
     * @return string
     */
    public function ajaxResponse(string $param, array $values): string
    {
        return json_encode([$param => $values]);
    }
}
