<?php $v->layout('template'); ?>
<div id="funcionarios" class="container mt-200">

    <!-- Link para Voltar à Página Anterior -->
    <a href="<?= url("admin"); ?>" class="btn btn-warning">
        <i class="fas fa-arrow-left"></i> Voltar
    </a>

    <div class="text-center">
        <h2 class="section-heading text-uppercase">Funcionários</h2>
        <h3 class="section-subheading text-dark">Veja a lista de todos os funcionários</h3>
    </div>

    <h2>Lista de Funcionários</h2>

    <!-- Botão para Adicionar Funcionário -->
    <a href="<?= url("admin/add/funcionario"); ?>" class="btn btn-success mb-3">
        <i class="fas fa-plus"></i> Adicionar Funcionário
    </a>

    <!-- Tabela para exibir a lista de funcionários -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Funções</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
<<<<<<< HEAD
            <?php foreach ($funcionarios as $funcionario) : ?>
                <tr>
                    <td><img src="<?= theme('img/funcionarios/' . $funcionario->foto); ?>" alt="Funcionário 2" class="user-photo"></td>
                    <td>Falcão</td>
                    <td>Cabelo</td>
                    <td>

                        <a href="<? url("admin/add_funcionario/{$funcionario->id}"); ?>?>" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <a href=<? url("removerUser/{$funcionario->id}") ?>class="btn btn-danger">
                            <i class="fas fa-trash"></i> Excluir
                        </a>
                        <a href="<?= url("admin/funcionario/agenda/2"); ?>" class="btn btn-info">
                            <i class="fas fa-calendar"></i> Agendamentos
                        </a>
                    </td>
                </tr>
            <?php endforeach ?>

=======

        <?php
            foreach ($funcionarios as $funcionario):
        ?>

            <tr>
                <td><img src="<?=image($funcionario->foto);?>"alt="Funcionário 1" class="user-photo" height="60"></td>
                <td><?=$funcionario->nome?></td>
                <td></td>
                <td>
                    <a href="/editar-funcionario/1" class="btn btn-warning">
                        <i class="fas fa-edit"></i> Editar
                    </a>

                    <?php 
                        if ($funcionario->status == "ativo"): ?>
                            
                            <a href="<?=url("removerUser/{$funcionario->id}")?>" class="btn btn-success">
                        <i class="fas fa-check"></i> Ativo
                    </a>
                    
                    <?php else: 
                        ?>

                    <a href="<?=url("removerUser/{$funcionario->id}")?>" class="btn btn-danger">
                        <i class="fas fa-ban"></i>Inativo
                    </a>
                        
                    <?php endif;?>
                        
                    <a href="<?= url("admin/funcionario/agenda/1"); ?>" class="btn btn-info">
                        <i class="fas fa-calendar"></i> Agendamentos
                    </a>
                </td>
            </tr>

            <?php endforeach; ?>
          
            <!-- Adicione mais linhas para mais funcionários -->
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        </tbody>
    </table>
</div>
