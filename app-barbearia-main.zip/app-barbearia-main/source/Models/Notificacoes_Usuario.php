<?php

namespace Source\Models;

use CoffeeCode\DataLayer\DataLayer;

class Notificacoes_Usuario extends DataLayer
{
    public function __construct()
    {
        parent::__construct("notificacoes_usuario", ["notif_id","user_id","view","status","created_at","update_at","id", true]);
    }
}
