<?php $v->layout('template'); ?>
<section class="page-section bg-dark text-white" id="services">


<div class="container">

    <div>
        <!-- Link para Voltar à Página Anterior -->
<a href="<?=url("admin"); ?>" class="btn btn-warning mt-50">
    <i class="fas fa-arrow-left"></i> Voltar
</a>
</div>

    <form class="form" id="form" action="<?= url("admin/servico"); ?>" method="post">

    <div class="col-md-12">
        <div class="form-group">
            <label for="Estilo">Estilo:</label><br>
            <input type="text" id="Estilo" name="descricao">
    </div>

    <div class="col-md-12">
        <div class="form-group">
            <label for="Valor">Valor:</label><br>
            <input type="text" id="Valor" name="valor">

    <div class="col-md-12">
        <div class="form-group">
            <label for="Promocao">Promoção:</label><br>
            <input type="text" id="Promocao" name="promocao">

    <div class="col-md-12">
        <div class="form-group">
            <label for="valor_promocional">Valor Promocional:</label><br>
            <input type="text" id="valor_promocional" name="valor_promocao">

    <div class="col-md-12">
        <div class="form-group">
                <label for="Status">Status:</label><br>
                 <input type="text" id="Status" name="status">
            
    <div class="col-md-12">
        <div class="form-group">
                <label for="Foto">Foto:</label><br>
                <input type="File" id="Foto" name="foto">
                
    <div class="form-group">
            <div class="form_callback"></div>
        </div>    
                
    <div class="form-group">
        <?= methodForm("criar"); ?>
        <input type="submit" value="Cadastrar">
     </div>

        <div class="text-center">
            <h2 class="section-heading text-uppercase">Serviços</h2>
            <h3 class="section-subheading text-White">Serviços oferecidos pela Barbearia</h3>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme('img/corte.jpg'); ?>" alt="..." />
                    <h4>Cortes</h4>

                    <a href="<?= url("servico/cortes"); ?>" class="btn btn-primary btn-lg">Serviços</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme('img/pigmentacao.jpg') ?>" alt="..." />
                    <h4>Pigmentações</h4>

                    <a class="btn btn-primary btn-sm text-uppercase mx-2" href="#services">Ver mais</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme("img/tintura.avif") ?>" alt="..." />
                    <h4>Pinturas</h4>

                    <a class="btn btn-primary btn-sm text-uppercase mx-2" href="#services">Ver mais</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <p class="large text-dark"></p>

            </div>
        </div>
    </div>

</section>