<?php $v->layout('template'); ?>
<div id="agendamentos" class="container mt-200">
    <!-- Link para Voltar à Página de Funcionários -->
    <a href="<?= url("admin/funcionario"); ?>" class="btn btn-warning">
        <i class="fas fa-arrow-left"></i> Voltar
    </a>

    <div class="text-center">
        <h2 class="section-heading text-uppercase">Agendamentos de Funcionário</h2>
        <h4 class="section-subheading text-dark">Veja todos os agendamentos do funcionário</h4>
    </div>

    <h5>Funcionário: [Nome do Funcionário]</h5>
    <h6>Funções: [Funções do Funcionário]</h6>

    <div id="accordion" class="mb-200">
        <div class="card">
            <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                    <button class="btn btn-warning" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Cadastrar Horários Disponíveis <i class="fas fa-plus"></i>
                    </button>
                </h5>
            </div>
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                    <h4>Datas Disponíveis do Funcionário:</h4>
                    <ul>
                        <li>Data 1</li>
                        <li>Data 2</li>
                        <!-- Adicione mais datas disponíveis aqui -->
                    </ul>
                    <h4>Datas Indisponíveis do Funcionário:</h4>
                    <ul>
                        <li>Data 3</li>
                        <li>Data 4</li>
                        <!-- Adicione mais datas indisponíveis aqui -->
                    </ul>
                    <h4>Cadastrar Nova Data:</h4>
                    <form action="/cadastrar-data-funcionario" method="post" class="mb-3">
                        <label for="nova-data">Nova Data:</label>
                        <input type="date" id="nova-data" name="nova-data" required>
            
                        <label for="novo-horario">Novo Horário:</label>
                        <input type="time" id="novo-horario" name="novo-horario" required>
                        <button type="submit" class="btn btn-primary">Cadastrar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Tabela para exibir os agendamentos -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Data</th>
                <th>Horário Disponível</th>
                <th>Serviço</th>
                <th>Preço</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>[Data do Agendamento]</td>
                <td>[Horário Disponível]</td>
                <td>[Nome do Serviço]</td>
                <td>R$ [Preço do Serviço]</td>
                <td>[Status do Agendamento]</td>
            </tr>
            <tr>
                <td>[Data do Agendamento]</td>
                <td>[Horário Disponível]</td>
                <td>[Nome do Serviço]</td>
                <td>R$ [Preço do Serviço]</td>
                <td>[Status do Agendamento]</td>
            </tr>
            <!-- Adicione mais linhas para mais agendamentos -->
        </tbody>
    </table>
</div>
