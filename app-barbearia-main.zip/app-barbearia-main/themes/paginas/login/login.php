<?php $v->layout('template'); ?>

<section class="page-section" id="login-container">

    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Login</h2>
            <h3 class="section-subheading text-dark">Seja bem vindo a nossa barbearia</h3>
        </div>

        <form action="seu_script_de_login.php" method="post">

            <div class="col-md-12">
                <div class="form-group">
                    <label for="email">Email:</label><br>
                    <input type="email" id="email" name="email" required>

                </div>
                <div class="form-group">
                    <label for="senha">Senha:</label><br>
                    <input type="password" id="senha" name="senha" required>
                </div>

                <div class="form-group">
                    <input type="submit" value="Login">
                    <a class="btn_cadastrar" href="<?= url("cadastrar"); ?>">Cadastrar</a>
                </div>
                <div class="form-group">
                    <a class="btn_recuperar_senha" href="recuperar_senha.html">Esqueci minha senha!</a>
                </div>


            </div>
        </form>
    </div>

</section>