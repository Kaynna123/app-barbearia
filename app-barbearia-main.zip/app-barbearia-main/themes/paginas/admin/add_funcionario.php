<?php $v->layout('template'); ?>
<div id="adicionar-funcionario" class="container mt-200">
   
<!-- Link para Voltar à Página Anterior -->
<a href="<?=url("admin/funcionario"); ?>" class="btn btn-warning ">
    <i class="fas fa-arrow-left"></i> Voltar
</a>

    <div class="text-center ">
        <h2 class="section-heading text-uppercase">Adicionar Funcionário</h2>
        <h3 class="section-subheading text-dark">Cadastre um novo funcionário com suas funções</h3>
    </div>

    <h2>Adicionar Funcionário</h2>

    <!-- Formulário para Adicionar Funcionário -->
    <form action="/adicionar-funcionario" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome do Funcionário</label>
            <input type="text" id="nome" name="nome" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="funcoes" class="form-label">Funções do Funcionário (separe por vírgula)</label>
            <input type="text" id="funcoes" name="funcoes" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="foto" class="form-label">Carregar Foto do Funcionário</label>
            <input type="file" id="foto" name="foto" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Adicionar Funcionário
        </button>
    </form>
</div>
