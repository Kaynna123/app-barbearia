<?php $v->layout('template'); ?>
<div id="usuarios-cadastrados" class="container mt-200">
    
<!-- Link para Voltar à Página Anterior -->
<a href="<?=url("admin"); ?>" class="btn btn-warning">
    <i class="fas fa-arrow-left"></i> Voltar
</a>

    <div class="text-center">
        <h2 class="section-heading text-uppercase">Usuários Cadastrados</h2>
        <h3 class="section-subheading text-dark">Veja a lista de todos os usuários cadastrados</h3>
    </div>

    <h2>Lista de Usuários</h2>

    <!-- Tabela para exibir a lista de usuários -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Gênero</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><img src="caminho-para-foto-usuario-1.jpg" alt="Usuário 1" class="user-photo"></td>
                <td>Usuário 1</td>
                <td>usuario1@email.com</td>
                <td>(11) 1234-5678</td>
                <td>Masculino</td>
                <td>Ativo</td>
                <td>
                    <a href="/editar-usuario/1" class="btn btn-warning">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <button class="btn btn-danger" data-toggle="modal" data-target="#inativarUsuario1">
                        <i class="fas fa-ban"></i> Inativar
                    </button>
                </td>
            </tr>
            <tr>
                <td><img src="caminho-para-foto-usuario-2.jpg" alt="Usuário 2" class="user-photo"></td>
                <td>Usuário 2</td>
                <td>usuario2@email.com</td>
                <td>(22) 9876-5432</td>
                <td>Feminino</td>
                <td>Inativo</td>
                <td>
                    <a href="/editar-usuario/2" class="btn btn-warning">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <button class="btn btn-success" data-toggle="modal" data-target="#ativarUsuario2">
                        <i class="fas fa-check"></i> Ativar
                    </button>
                </td>
            </tr>
            <!-- Adicione mais linhas para mais usuários -->
        </tbody>
    </table>
</div>
