<?php $v->layout('template'); ?>
<section class="page-section" id="agendamento">
    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Agendamentos</h2>
            <h3 class="section-subheading text-dark">Esses são seus agendamentos.</h3>
        </div>
        

        <div class="notification">Seu corte de cabelo ficou marcado para o dia .
        <sub class="notification_date">10/10/2023 17:00</sub>
        </div>

        <div class="notification error"> Seu agendamento foi cancelado por perda de prazo.
        <sub class="notification_date">09/10/2023</sub>

        
        
        </div>

    </div>
    
</section>

