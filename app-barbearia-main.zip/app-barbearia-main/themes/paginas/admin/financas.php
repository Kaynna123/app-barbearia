<?php $v->layout('template'); ?>
<div id="financas" class="container mt-200">

    <!-- Link para Voltar à Página Anterior -->
<a href="<?=url("admin"); ?>" class="btn btn-warning ">
    <i class="fas fa-arrow-left"></i> Voltar
</a>

    <div class="text-center">
        <h2 class="section-heading text-uppercase">Finanças</h2>
        <h3 class="section-subheading text-dark">Veja o resumo financeiro da barbearia</h3>
    </div>

    <h2>Resumo Financeiro</h2>

    <!-- Seção de Entradas de Dinheiro -->
    <div class="mb-4">
        <h3>Entradas de Dinheiro</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>01/10/2023</td>
                    <td>Venda de serviços</td>
                    <td>R$ 500,00</td>
                </tr>
                <!-- Adicione mais linhas para mais entradas de dinheiro -->
            </tbody>
        </table>
    </div>

    <!-- Seção de Saídas de Dinheiro -->
    <div class="mb-4">
        <h3>Saídas de Dinheiro</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>05/10/2023</td>
                    <td>Compra de equipamentos</td>
                    <td>R$ 300,00</td>
                </tr>
                <!-- Adicione mais linhas para mais saídas de dinheiro -->
            </tbody>
        </table>
    </div>

    <!-- Seção de Agendamentos do Mês -->
    <div class="mb-4">
        <h3>Agendamentos do Mês</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Cliente</th>
                    <th>Valor Pago</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>15/10/2023</td>
                    <td>Cliente 1</td>
                    <td>R$ 50,00</td>
                </tr>
                <!-- Adicione mais linhas para mais agendamentos -->
            </tbody>
        </table>
    </div>

    <!-- Seção de Despesas com Equipamentos e Produtos -->
    <div class="mb-4">
        <h3>Despesas com Equipamentos e Produtos</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>10/10/2023</td>
                    <td>Compra de tesouras</td>
                    <td>R$ 50,00</td>
                </tr>
                <!-- Adicione mais linhas para mais despesas com equipamentos e produtos -->
            </tbody>
        </table>
    </div>

    <!-- Seção de Retirada do Pagamento dos Funcionários -->
    <div>
        <h3>Retirada do Pagamento dos Funcionários</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Funcionário</th>
                    <th>Valor Retirado</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>20/10/2023</td>
                    <td>Funcionário 1</td>
                    <td>R$ 100,00</td>
                </tr>
                <!-- Adicione mais linhas para mais retiradas de pagamento dos funcionários -->
            </tbody>
        </table>
    </div>
</div>
