<?php

namespace Source\App;

use Source\App\Controller;
use Source\Models\Usuario;
use Source\Models\Servicos;
use CoffeeCode\Uploader\Image;
use FFI;
use Source\Models\Agendamento;
use Source\Models\Notificacao;


/**
 * Web Controller
 * @package Source\Web
 */
class Admin extends Controller
{

    protected $module = 1; //dashboard

    public function __construct($router)
    {
        parent::__construct($router);
<<<<<<< HEAD
        if (!$this->logged_user() || ($this->logged_user()->tipo == "cliente")) {

            flash("danger", "Faça login para continuar...");
            $this->router->redirect("auth.login");
            return;
=======

        if (!$this->logged_user() || ($this->logged_user()->tipo == "cliente")) {

            flash("danger","Faça login para continuar...");
            $this->router->redirect("auth.login");
            return;

>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        }
    }

    public function home(): void
    {


        $pageName = "HOME";
        echo $this->view->render("admin/admin", [
            "title" => $pageName,
            "menuActive" => 'home'
        ]);
        return;
    }

    public function servico(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {

            $servico = new Servicos();
            $servico->descricao    = $data["descricao"];
            $servico->valor    = $data["valor"];
            $servico->promocao   = $data["promocao"];
            $servico->valor_promocao = $data["valor_promocao"];
            $servico->status     =  $data["status"];
            $servico->foto    = $_FILES["foto"]["name"];
            $servico->save();
            var_dump($servico);
            return;
        }


        $pageName = "SERVICO";
        echo $this->view->render("admin/servico", [
            "title" => $pageName,
            "menuActive" => 'servico'
        ]);
        return;
    }

    
    public function cadastrar(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {

            $usuario = new Usuario();
            $usuario->nome     = $data["nome"];
            $usuario->email    = $data["email"];
            $usuario->senha    = passwd($data["senha"]);
            $usuario->genero   = $data["genero"];
            $usuario->telefone = $data["telefone"];
            $usuario->tipo     = $data["tipo"];
            

            var_dump($usuario->save());
            return;
        }

       
        $pageName = "CADASTRAR";
        echo $this->view->render("admin/cadastrar", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function agendamentos(array $data): void
    {


       $agendamentos = (new Agendamento())->find()->fetch(true);
        $pageName = "AGENDAMENTOS";
        echo $this->view->render("admin/agendamentos", [
            "title" => $pageName,
            "agendamentos" => $agendamentos,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function notificacao(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {
            $notificacao = new Notificacao();
            $notificacao->foto = $data["foto"];
            $notificacao->descricao = $data["descricacao"];

            var_dump($notificacao);
            return;
        }
        $pageName = "SERVICO";
        echo $this->view->render("admin/notificacao", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function add_notificacao(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {
            $notificacao = new Notificacao();
            $notificacao->foto = $data["foto"];
            $notificacao->descricao = $data["descricacao"];

            var_dump($notificacao);
            return;
        }
        $pageName = "SERVICO";
        echo $this->view->render("admin/add_notificacao", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function funcionario(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {

            $usuario = new Usuario();
            $usuario->nome     = $data["nome"];
            $usuario->email    = $data["email"];
            $usuario->senha    = passwd($data["senha"]);
<<<<<<< HEAD
            $usuario->genero   = $data["genero"];
            $usuario->telefone = $data["telefone"];
            $usuario->tipo     = $data["tipo"];


=======
            $usuario->tipo     = "funcio";
            
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
            var_dump($usuario->save());
            return;
        }

<<<<<<< HEAD

        $funcionarios = (new Usuario())->tipoUsuario("funcio");


=======
        $funcionarios = (new Usuario())->find("tipo = :tipo", "tipo=funcio")->fetch(true);
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        $pageName = "FUNCIONARIO";
        echo $this->view->render("admin/funcionario", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function financas(array $data): void
    {


      
        $pageName = "FINANCAS";
        echo $this->view->render("admin/financas", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function usuarios(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {

            $usuario = new Usuario();
            $usuario->nome     = $data["nome"];
            $usuario->email    = $data["email"];
            $usuario->senha    = passwd($data["senha"]);
            $usuario->genero   = $data["genero"];
            $usuario->telefone = $data["telefone"];
            $usuario->tipo     = $data["tipo"];
            

            var_dump($usuario->save());
            return;
        }

       
        $pageName = "USUARIOS";
        echo $this->view->render("admin/usuarios", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function add_funcionario(array $data): void
    {
        if (isset($data["metodo"]) == "criar") {

            $usuario = new Usuario();
            $usuario->nome     = $data["nome"];
            $usuario->email    = $data["email"];
            $usuario->senha    = passwd($data["senha"]);
<<<<<<< HEAD
            $usuario->genero   = $data["genero"];
            $usuario->telefone = $data["telefone"];
            $usuario->tipo     = $data["tipo"];


            var_dump($usuario->save());
            return;
        }


=======
            $usuario->tipo     = "funcio";
            
            if (!empty($_FILES["foto"]["name"])) {
                $image = (new Image("storage","funcionario"));
                $upload = $image->upload($_FILES['foto'], $usuario->nome  . time());
    
                if ($usuario->foto) {
                    if (file_exists($usuario->foto)) {
                        unlink($usuario->foto);
                    }
                }    
            if ($upload) {
                $usuario->foto = $upload;
            }  

            var_dump($usuario->save());
            return;
        } 
    }

    
       
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        $pageName = "ADD_FUNCIONARIO";
        echo $this->view->render("admin/add_funcionario", [
            "title" => $pageName,
            "menuActive" => 'admin'
        ]);
        return;
    }

    public function agendamentos_funcionarios(array $data): void
    {


       $agendamentos = (new Agendamento())->find()->fetch(true);
        $pageName = "AGENDAMENTOS_FUNCIONARIOS";
        echo $this->view->render("admin/agendamentos_funcionarios", [
            "title" => $pageName,
            "agendamentos" => $agendamentos,
            "menuActive" => 'admin'
        ]);
        return;
    }
}
