<?php $v->layout('template'); ?>
<section class="page-section " id="notificacao">

<div class="ml-100"> 
<!-- Link para Voltar à Página Anterior -->
<a href="<?=url("admin"); ?>" class="btn btn-warning ">
    <i class="fas fa-arrow-left"></i> Voltar
</a>

</div>

    <div class="container">

        <div class="text-center">
            <h2 class="section-heading text-uppercase">Agendados!!!</h2>
            <h3 class="section-subheading text-dark">agendados pelos clientes.</h3>
        </div>


        
    <div class="row agenda-row">

    <?php
    var_dump($agendamentos);

    if($agendamentos):
        foreach ($agendamentos as $agendamento):
    ?>

    <div class="col-lg-4">
        <div class="cont-agendamentos">Nome: <?= $agendamento->cliente; ?> agendou um <?= $agendamento->serv_id; ?>  
            <h6 class="agenda-data">Data: <?= $agendamento->datahora; ?></h6>
            <sub class="agenda-func">Funcionario: <?= $agendamento->func_id; ?></sub>

        </div>
        </div>

        <?php
    endforeach;
    endif; ?>



        <div class="col-lg-4">
        <div class="cont-agendamentos">Bruce Wayne marcou um corte de barba
            <h6 class="agenda-data">10/10/2023 17:00</h6>
            <sub class="agenda-func">Funcionario: Zé da Timba</sub>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="cont-agendamentos">Bruce Wayne marcou um corte de barba
            <h6 class="agenda-data">10/11/2023 17:00</h6>
            <sub class="agenda-func">Funcionario: Zé da Timba</sub>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="cont-agendamentos">Bruce Wayne marcou um corte de barba
            <h6 class="agenda-data">10/10/2023 17:00</h6>
            <sub class="agenda-func">Funcionario: Zé da Timba</sub>
        </div>
    </div>
    </div>


    </div>

</section>

