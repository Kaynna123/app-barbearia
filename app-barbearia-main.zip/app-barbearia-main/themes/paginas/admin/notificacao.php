<?php $v->layout('template'); ?>
<div id="notificacoes" class="container mt-100">

<div class="text-center">
    <h2 class="section-heading text-uppercase">Notificações</h2>
    <h3 class="section-subheading text-dark">Essas são suas notificações</h3>
</div>
    <h2>Notificações</h2>
    <p>Gerencie as notificações que os usuários irão receber:</p>

    <!-- Lista de Notificações -->
    <ul class="list-group mt-4">
    <a href="<?= url("admin/add/notificacao"); ?>" class="btn btn-success mb-3">
        <i class="fas fa-plus"></i> Adicionar Notificação
    </a>
        <li class="list-group-item">
            <i class="fas fa-bell"></i> Novo horário disponível em 12 de outubro.
            <a href="" class="btn-editar">Editar</a>
            <a href="" class="btn-excluir">Excluir</a>
        </li>
        <li class="list-group-item">
            <i class="fas fa-bell"></i> Promoção especial de corte de cabelo!
            <a href="" class="btn-editar">Editar</a>
            <a href="" class="btn-excluir">Excluir</a>
        </li>
        <li class="list-group-item">
            <i class="fas fa-bell"></i> Lembrete: Seu agendamento está chegando em breve.
            <a href="" class="btn-editar">Editar</a>
            <a href="" class="btn-excluir">Excluir</a>
        </li>
        
    </ul>
</div>
        <!-- retorno da aplicação aqui! -->
        <div class="form-group">
            <div class="form_callback"></div>
                </div>
        <!-- ./retorno da aplicação aqui! -->

            <div class="form-group">
                <?= methodForm("criar"); ?>
            </div>
    </div>
</section>

