<?php
date_default_timezone_set('America/Recife');

/**
 * PROJECT URLs
 */
if ($_SERVER['HTTP_HOST'] == 'localhost') {
    define("ROOT", "http://localhost/app-barbearia");
    define("DATABASE", [
        "dbname" => 'app_barbearia',
        "username" => 'root',
        "passwd" => '',
    ]);
} else {
    define("ROOT", "https://fabvale.com.br/app-barbearia");
    define("DATABASE", [
        "dbname" => '',
        "username" => '',
        "passwd" => '',
    ]);
}


define("CONF_URL_BASE", ROOT);
define("CONF_URL_TEST", ROOT);
/**
 * SITE
 */

define("APP_NAME", "NOME DO APP");
define("VERSION", "beta");
define("DEVELOPER", "FabVale Inovação e Tecnologia");
define("DEVELOPER_SITE", "https://fabvale.com.br");


/**
 * DATABASE
 */
define("DATA_LAYER_CONFIG", [
    "driver" => "mysql",
    "host" => "localhost",
    "port" => "3307",
    "dbname" => DATABASE["dbname"],
    "username" => DATABASE["username"],
    "passwd" => DATABASE["passwd"],
    "options" => [
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
        PDO::ATTR_CASE => PDO::CASE_NATURAL
    ]
]);


/**
 * VIEW
 */
define("CONF_VIEW_THEME", "paginas");
define("CONF_THEME_STYLE", "estilos");
define("CONF_VIEW_EXT", "php");


/**
 * DATES
 */
define("CONF_DATE_BR", "d/m/Y H:i:s");
define("CONF_DATE_APP", "Y-m-d H:i:s");

/**
 * PASSWORD
 */
define("CONF_PASSWD_MIN_LEN", 8);
define("CONF_PASSWD_MAX_LEN", 40);
define("CONF_PASSWD_ALGO", PASSWORD_DEFAULT);
define("CONF_PASSWD_OPTION", ["cost" => 10]);
