<?php $v->layout('template'); ?>

<!--Imagem-->
<section class="page-section" id="notificacao">
    <div class="container">
        <div class="row">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">PERFIL</h2>
                <h3 class="section-subheading text-dark">Seu perfil !!!</h3>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-4">
                <div class="team-member">
                    <img class="mx-auto rounded-circle" src="<?= theme('img/corte.jpg'); ?>" alt="..." />
                </div>
            </div>

            <div class="col-lg-8">
                <form action="<?= url("perfil"); ?>" method="post">
                    <div class="notification error">
                        <i class="fa fa-user"></i>
                        <input type="text" name="nome" class="perfil-nome" value="Nome" placeholder="Digite seu nome">
                    </div>

                    <div class="notification">
                        <i class="fas fa-phone"></i>
                        <input type="text" name="nome" class="perfil-nome" value="Telefone" placeholder="Digite um contato">
                    </div>

                    <div class="notification">
                        <i class="fas fa-genderless"></i>
                        <input type="text" name="nome" class="perfil-nome" value="Gênero" placeholder="Digite o Genero ">
                    </div>

                    <div class="notification error">
                        <i class="fas fa-envelope-open"></i>
                        <input type="text" name="nome" class="perfil-nome" value="E-mail" placeholder="Digite um Email ">
                    </div>
                    <div class="text-right">
                        <?= methodForm("alterar"); ?>
                        <button class="btn btn-primary btn-sm text-uppercase mx-2">Alterar Perfil</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>