<?php

namespace Source\Models;

use CoffeeCode\DataLayer\DataLayer;

class ServicoFuncionario extends DataLayer
{
    public function __construct()
    {
        parent::__construct("servicos_funcionarios", ["serv_id", "func_id"],"id", false);
    }
}
