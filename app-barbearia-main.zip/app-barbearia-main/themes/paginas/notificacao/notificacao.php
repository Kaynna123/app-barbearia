<?php $v->layout('template'); ?>
<section class="page-section" id="notificacao">
    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Notificações</h2>
            <h3 class="section-subheading text-dark">Essas são suas notificações.</h3>
        </div>

        <div class="notification">Esta é uma notificação visualizada.
        <sub class="notification_date">10/10/2023 17:00</sub>
        </div>

        <div class="notification error">Esta é uma notificação não visualizada.
        <sub class="notification_date">10/10/2023 17:00</sub>
        </div>

        <div class="notification">
            Esta é outra notificação visualizada.

        <sub class="notification_date">10/10/2023 17:00</sub>

        </div>
    </div>
</section>

