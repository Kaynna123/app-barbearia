<?php

namespace Source\Models;

use CoffeeCode\DataLayer\DataLayer;

class Agendamento extends DataLayer
{
    public function __construct()
    {
        parent::__construct("agendamentos", ["user_id","serv_id","func_id","datahora","valor","status","status_pagamento","id",false]);
    }

    function cliente() 
    {
        
    }

}
