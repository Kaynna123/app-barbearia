<?php

namespace Source\Models;

use CoffeeCode\DataLayer\DataLayer;

class Servicos extends DataLayer
{
    public function __construct()
    {
        parent::__construct("servicos", ["descricao","valor","status"],"id",false);
    }
}
