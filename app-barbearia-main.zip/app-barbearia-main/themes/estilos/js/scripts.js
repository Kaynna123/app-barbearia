$(function () {
    $("form:not('.ajax_off')").on('submit', (function (e) {

        e.preventDefault();
        var form = $(this);
        var action = form.attr("action");
        var data = new FormData(this);
        $.ajax({
            url: action,
            type: "POST",
            dataType: "json",
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function () {
                ajax_load("open");
            },
            success: function (su) {
                ajax_load("close");
                if (su.message) {
                    if (su.message.callback) {
                        var view = '<div class="alert alert-' + su.message.type + '">' + su.message.message + '</div>';
                        $(su.message.callback).html(view);
                        $(su.message.callback).effect("bounce");
                        return;
                    }
                    var view = '<div class="alert alert-' + su.message.type + '">' + su.message.message + '</div>';
                    $(".form_callback").html(view);
                    $(".form_callback").effect("bounce");
                    return;
                }
                if (su.redirect) {
                    window.location.href = su.redirect.url;
                }
            },
            error: function (e) {
                ajax_load("close");
                // alert('error');
                $(".form_callback").html(e).fadeIn();
            }
        });
    }));
});


function ajax_load(action) {
    ajax_load_div = $(".ajax_load");


    if (action === "open") {
        ajax_load_div.fadeIn(200).css("display", "flex");
    }

    if (action === "close") {
        ajax_load_div.fadeOut(200);
    }
}

$("[data-image]").change(function (e) {
    var changed = $(this);
    var file = this;

    if (file.files && file.files[0]) {
        var render = new FileReader();

        render.onload = function (e) {
            $(changed.data("image")).fadeTo(100, 0.1, function () {
                $(this).css("background-image", "url('" + e.target.result + "')")
                    .fadeTo(100, 1);
            });
        };

        render.readAsDataURL(file.files[0]);
    }
});