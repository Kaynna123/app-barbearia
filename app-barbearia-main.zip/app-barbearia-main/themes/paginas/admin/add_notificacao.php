<?php $v->layout('template'); ?>
<div id="adicionar-notificacao" class="container mt-5">

<!-- Link para Voltar à Página Anterior -->
<a href="<?=url("admin/notificacao"); ?>" class="btn btn-secondary mt-150">
    <i class="fas fa-arrow-left"></i> Voltar
</a>

<div class="text-center">
    <h2 class="section-heading text-uppercase">Adicionar Notificações</h2>
    <h3 class="section-subheading text-dark">Altere suas notificações aqui</h3>
</div>

    <h2>Adicionar Notificação</h2>

    <!-- Formulário para Adicionar Notificação -->
    <form action="/adicionar-notificacao" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="titulo" class="form-label">Título da Notificação</label>
            <input type="text" id="titulo" name="titulo" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="mensagem" class="form-label">Mensagem da Notificação</label>
            <textarea id="mensagem" name="mensagem" class="form-control" rows="4" required></textarea>
        </div>
        <div class="mb-3">
            <label for="foto" class="form-label">Carregar Foto</label>
            <input type="file" id="foto" name="foto" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Salvar Notificação
        </button>
    </form>
</div>
