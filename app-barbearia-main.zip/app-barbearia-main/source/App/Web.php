<?php

namespace Source\App;

use Source\App\Controller;
use Source\Models\Servicos;
<<<<<<< HEAD
use CoffeeCode\Uploader\Image;
use Source\Models\Agendamento;
=======
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
use Source\Models\Notificacao;
use Source\Models\Agendamento;
use Source\Models\Usuario;

/**
 * Web Controller
 * @package Source\Web
 */
class Web extends Controller
{

    protected $module = 1; //dashboard

    public function __construct($router)
    {
        parent::__construct($router);
        // if (empty($_SESSION["user_id"]) || !$this->logged_user() || $this->logged_user()->clie_id != 0) {
        //     unset($_SESSION["user_id"]);
        //     flash("danger", "Acesso negado. Por favor logue-se.");
        //     $this->router->redirect("auth.login");
        // }
    }

    /** DASHBOARD */
    public function home(): void
    {

        $servicos = (new Servicos())->find()->fetch(true);
<<<<<<< HEAD
        $funcionarios = (new Usuario())->find()->fetch(true);

=======
        $funcionarios = (new Usuario())->find("tipo = :tipo", "tipo=funcio")->fetch(true);
        
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        $pageName = "HOME";
        echo $this->view->render("_dashboard/home", [
            "title" => $pageName,
            "servicos"=> $servicos,
            "funcionarios"=> $funcionarios,
            "menuActive" => 'home'
        ]);
        return;
    }

    public function notificacao(array $data): void
    {
        if (isset($data["metodo"]) == "notificacao") {
            $notificacao = (new Notificacao());
            $notificacao->descricao = $data["descricao"];
            $notificacao->save();
        }

        $pageName = "NOTIFICACAO";
        echo $this->view->render("notificacao/notificacao", [
            "title" => $pageName,
        ]);
        return;
    }

    public function cadastrar(array $data): void
    {
        if (isset($data["metodo"]) and $data["metodo"] == "criar") {

            $usuario = new Usuario();
            $usuario->nome     = $data["nome"];
            $usuario->email    = $data["email"];
            $usuario->senha    = passwd($data["senha"]);
            $usuario->genero   = $data["genero"];
            $usuario->telefone = $data["telefone"];
            $usuario->tipo     = "cliente";

<<<<<<< HEAD
            //validar usuario cadastrado
            $busca_email = (new Usuario())->find("email=:email", "email={$data["email"]}")->count;

            if ($busca_email >= 1) {
                echo $this->ajaxResponse("message", [
                    "type" => "danger",
=======
            #validar o email
            $buscar_email = (new Usuario())->find("email=:email", "email={$data["email"]}")->count();

            if ($buscar_email >=1) {
                echo $this->ajaxResponse("message",[
                    "type" => "danger ",
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
                    "message" => "Email já Cadastrado."
                ]);
                return;
            }

            if ($usuario->save()) {
<<<<<<< HEAD
                flash("success", "Usuário Cadastrado !!!");
                echo $this->ajaxResponse("redirect", [
=======
                flash("success","Cadastrado, agora só falta o login :");
                echo $this->ajaxResponse("redirect",[
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
                    "url" => url("login"),
                ]);
                return;
            }

            var_dump($usuario->save());
            return;
        }
        $pageName = "CADASTRAR";
        echo $this->view->render("cadastrar/cadastrar", [
            "title" => $pageName,
            "menuActive" => 'cadastrar'
        ]);
    }


    public function contact(): void
    {
        $pageName = "CONTATO";
        echo $this->view->render("_dashboard/contato", [
            "title" => $pageName,
            "pageName" => $pageName,
            "menuActive" => 'contact'
        ]);
    }
    public function agendamentos(array $data): void

    {
        if (isset($date["metodo"]) == "agendar") {
            $agendar = (new Agendamento());
            $agendar->user_id = $data[""];
            $agendar->func_id = $data["funcionario"];
            $agendar->serv_id = $data["servico"];
            $agendar->datahora = $data["data_hora"];
            $agendar->valor = $data["valor"];
            $agendar->status_pagamento = "pendente";
            $agendar->save();
            return;
        }

        $pageName = "AGENDAMENTOS";
        echo $this->view->render("agendamentos/agendamentos", [
            "title" => $pageName,
            "pageName" => $pageName,
        ]);
        return;
    }
    public function agendar(array $data): void

    {
        if (isset($date["metodo"]) == "agendar") {
            $agendar = (new Agendamento());
            $agendar->user_id = $data[""];
            $agendar->func_id = $data["funcionario"];
            $agendar->serv_id = $data["servico"];
            $agendar->datahora = $data["data_hora"];
            $agendar->valor = $data["valor"];
            $agendar->status_pagamento = "pendente";
            $agendar->save();
            return;
        }
        $funcionarios = (new Usuario())->find("tipo = :tipo", "tipo=funcio")->fetch(true);

        $pageName = "AGENDAR";
        echo $this->view->render("agendamentos/agendar", [
            "title" => $pageName,
            "pageName" => $pageName,
<<<<<<< HEAD
            "funcionarios" => $funcionarios,
=======
            "funcionarios"=> $funcionarios,
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        ]);
        return;
    }

    public function servicos(array $data): void
    {
<<<<<<< HEAD


        $servicos = (new Servicos())->find()->fetch(true);
        $pageName = "SERVICOS";
        echo $this->view->render("servicos/forms", [
            "title" => $pageName,
            "servicos" => $servicos,
=======
        $servicos = (new Servicos())->find()->fetch(true);

        $pageName = "SERVICOS";
        echo $this->view->render("servicos/forms", [
            "title" => $pageName,
            "servicos"=> $servicos,
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        ]);
        return;
    }

    public function perfil(array $data): void
    {
        if (!$this->logged_user()) {
<<<<<<< HEAD
            flash("danger", "Faça login para continuar...");
            $this->router->redirect("auth.login");
            return;
        }
=======
            flash("danger","Faça login para continuar...");
            $this->router->redirect("auth.login");
            return;
        }

>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        if (isset($data["metodo"]) == "alterar") {

            $usuario = $this->logged_user();
            $usuario->nome     = $data["nome"];
            $usuario->email    = $data["email"];
<<<<<<< HEAD
            $usuario->genero   = empty($data["genero"]) ? NULL : $data["genero"];
            $usuario->telefone = $data["telefone"];

            $senha = $data["senha"];
            if (!empty($senha)) {
                $usuario->senha    = passwd($data["senha"]);
            }

            if (!empty($_FILES["foto"]["name"])) {
                $image = (new Image("storage", "usuarios"));
                $upload = $image->upload($_FILES['foto'], $usuario->nome . time());
=======
            $usuario->genero   = empty($data["genero"])?NULL:$data["genero"];
            $usuario->telefone = $data["telefone"];
            
            $senha = $data["senha"];

            if (!empty($senha)) {
                $usuario->senha = passwd($data["senha"]);
            }

            #VALIDAR SE O USUARIO PASSOU A FOTO
            if (!empty($_FILES["foto"]["name"])) {
                $image = (new Image("storage","usuario"));
                $upload = $image->upload($_FILES['foto'], $usuario->nome  . time());
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)

                if ($usuario->foto) {
                    if (file_exists($usuario->foto)) {
                        unlink($usuario->foto);
                    }
<<<<<<< HEAD
                }

                if ($upload) {
                    $usuario->foto = $upload;
                }
            }

            if ($usuario->save()) {
                flash("success", "Dados alterados !!!");
                echo $this->ajaxResponse("redirect", [
                    "url" => url("perfil")
                ]);
                return;
=======
                }    
            if ($upload) {
                $usuario->foto = $upload;
            }   
            }
            if ($usuario->save()) {
                flash("success","Dados alterados.");
                
                echo $this->ajaxResponse(
                "redirect",
                [
                "url" => url("perfil")
                ]
            );
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
            }
            return;
        }

        $pageName = "PERFIL";
        echo $this->view->render("_dashboard/perfil", [
            "title" => $pageName,
            "menuActive" => 'web'
        ]);
        return;
    }

<<<<<<< HEAD
    public function removerFoto()
    {
        $usuario = $this->logged_user();
        if ($usuario->foto and file_exists($usuario->foto)) {
            unlink($usuario->foto);
        }
        $usuario->foto = null;
        flash("success", "Foto Removida com sucesso");
        $this->router->redirect("web.perfil");
=======
    public function removerFoto(){
        
    $usuario = $this->logged_user();
    if ($usuario->foto and file_exists($usuario->foto)) {
        unlink($usuario->foto);
    }
    $usuario->foto = null;
    flash('success','Foto Removida com Sucesso');
    $this->router->redirect('web.perfil');
    }
    
    public function removerUser(array $data){

            $usuario = ( new Usuario())->findById($data['id']);
            $usuario->status = ($usuario->status=='ativo')?"inativo":"ativo";
            $usuario->save();
            flash('success','Foto Removida com Sucesso');
            $this->router->redirect('admin.funcionario');
   
>>>>>>> parent of dfe2b14 (Merge branch 'main' of https://github.com/atanaildo/app-barbearia)
        return;
    }
}
