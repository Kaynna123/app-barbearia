<?php
ob_start();
session_start();

require __DIR__ . "/vendor/autoload.php";
/**
 * APP
 */

use CoffeeCode\Router\Router;


$route = new Router(ROOT);
$route->namespace("Source\App");

/**
 * web
 */
$route->group(null);
$route->get("/", "Web:home", "web.home");
$route->get("/home", "Web:home");
$route->get("/servicos", "Web:servicos");
$route->get("/notificacao", "Web:notificacao");
$route->get("/agendamentos", "Web:agendamentos");
$route->get("/agendar", "Web:agendar");
$route->get("/perfil", "Web:perfil");
$route->post("/perfil", "Web:perfil");

$route->get("/cadastrar", "Web:cadastrar");
$route->post("/cadastrar", "Web:cadastrar");


$route->get("/contato", "Web:contact");
$route->get("/userprofile", "Web:userprofile", "web.userprofile");
$route->post("/userprofile", "Web:userprofile", "web.userprofile");

/** AUTH ADMIN */
$route->group("admin");
$route->get("/", "Admin:home");
$route->get("/cadastrar", "Admin:cadastrar");
$route->post("/cadastrar", "Admin:cadastrar");
$route->get("/servico", "Admin:servico");
$route->post("/servico", "Admin:servico");
$route->get("/agendamentos", "Admin:agendamentos");
$route->get("/funcionario", "Admin:funcionario");
$route->post("/funcionario", "Admin:funcionario");
$route->get("/financas", "Admin:financas");
$route->post("/financas", "Admin:financas");
$route->get("/usuarios", "Admin:usuarios");
$route->get("/add/funcionario", "Admin:add_funcionario");
$route->post("/add/funcionario", "Admin:add_funcionario");
$route->get("/funcionario/agenda/{id}", "Admin:agendamentos_funcionarios");
$route->post("/funcionario/agenda/{id}", "Admin:agendamentos_funcionarios");

$route->get("/notificacao", "Admin:notificacao");
$route->post("/notificacao", "Admin:notificacao");
$route->get("/add/notificacao", "Admin:add_notificacao");
$route->post("/notificacao", "Admin:notificacao");
$route->get("/add/notificacao", "Admin:add_notificacao");
$route->post("/notificacao", "Admin:editar_notificacao");
$route->get("/notificacao", "Admin:excluir_notificacao");


/**
 * LOGIN
 * CADASTRAR
 */

/** AUTH */
$route->group("login");
$route->get("/", "Auth:login");
$route->post("/", "Auth:login", "auth.login");
$route->get("/cadastrar", "Auth:cadastrar");

/** lockscreen */
$route->group("lockscreen");
$route->get("/", "Auth:lockscreen");
$route->post("/", "Auth:lockscreen", "auth.lockscreen");


/** logoff */
$route->group("logoff");
$route->get("/", "Auth:logoff");


/** forgotpassword */
$route->group("forgotpassword");
$route->get("/", "Auth:forgotpassword");



/** usuario */
$route->group("usuario");
$route->get("/", "Configuracoes:usuario");
$route->get("/{action}/{id}", "Configuracoes:usuario"); //action : editar / acesso
$route->post("/", "Configuracoes:usuario", "configuracoes.usuario");

/**
 * ERROR
 */
$route->group("ops");
$route->get("/{errcode}", "AppError:error", "apperror.error");
$route->get("/403", "AppError:acessonegado", "apperror.acessonegado");

/**
 * PROCESS
 */
$route->dispatch();
if ($route->error()) {
    $route->redirect("/ops/{$route->error()}");
}
ob_end_flush();
