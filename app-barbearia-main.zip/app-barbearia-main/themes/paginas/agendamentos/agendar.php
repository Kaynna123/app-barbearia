<?php $v->layout('template'); ?>
<section class="page-section bg-dark" id="agendamentos">
  <div class="container">
    <div class="text-center">
      <h2 class="section-heading text-uppercase">Barbeiros</h2>
      <h3 class="section-subheading text-White">Escolha um Profissional !!! </h3>
    </div>
    <div class="row">
      <div class="col-lg-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="<?= theme('img/TOM JOBIM.jpeg'); ?>" alt="..." />
          <h4>Tom Jobim</h4>
          <p class="text-white"></p>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Escolher</button>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="<?= theme('img/milton.jpeg') ?>" alt="..." />
          <h4>Milton Nascimento</h4>
          <p class="text-white"></p>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Escolher</button>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="<?= theme("img/download.jpeg") ?>" alt="..." />
          <h4>João Gilberto</h4>
          <p class="text-white"></p>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Escolher</button>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 mx-auto text-center">
        <p class="large text-dark"></p>
      </div>
    </div>
    <div class="container">
      <div class="text-center">
        <h2 class="section-heading text-uppercase text-white">Barbeiros</h2>
        <h3 class="section-subheading text-white">Escolha um Profissional !!! </h3>
      </div>
      <div class="row">
        <div class="col-lg-4">
          <div class="team-member">
            <img class="mx-auto rounded-circle" src="<?= theme('img/TOM JOBIM.jpeg'); ?>" alt="..." />
            <h4 class="text-white">Tom Jobim</h4>
            <p class="text-white"></p>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Escolher</button>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="team-member">
            <img class="mx-auto rounded-circle" src="<?= theme('img/milton.jpeg') ?>" alt="..." />
            <h4 class="text-white">Milton Nascimento</h4>
            <p class="text-white"></p>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Escolher</button>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="team-member">
            <img class="mx-auto rounded-circle" src="<?= theme("img/download.jpeg") ?>" alt="..." />
            <h4 class="text-white">João Gilberto</h4>
            <p class="text-white"></p>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Escolher</button>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-8 mx-auto text-center">
          <p class="large text-muted"></p>
        </div>
      </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <img class="rounded-circle" height="24" width="24" src="<?= theme('img/milton.jpeg') ?>" alt="..." />
        <h5 class="modal-title" id="exampleModalLabel"> TOM JOBIM</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row align-items-center">

          <div class="col-md-2">
            <div class="form-group">
              <label for="">Data:</label><br>
              <select name="DATA">
                <option value="valor1">30</option>
              </select>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="">Hora:</label><br>
              <select name="Hora">
                <option value="valor2">12:30</option>
              </select>

            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary">Salvar</button>
      </div>
    </div>
  </div>
</div>